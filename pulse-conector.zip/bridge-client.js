export function extensionRequest(command,args={},timeout=12000){
  return new Promise((resolve,reject)=>{
    const id=crypto.randomUUID();
    const listener=event=>{
      const m=event.data;
      if(event.source!==window||event.origin!==location.origin||m?.channel!=='patio:reply'||m.id!==id)return;
      cleanup();m.ok?resolve(m.data):reject(new Error(m.error||'A extensão não respondeu.'));
    };
    const timer=setTimeout(()=>{cleanup();reject(new Error('Extensão desconectada. Recarregue o Pátio em chrome://extensions ou edge://extensions e depois atualize este painel no mesmo navegador.'))},timeout);
    const cleanup=()=>{clearTimeout(timer);window.removeEventListener('message',listener)};
    window.addEventListener('message',listener);
    window.postMessage({channel:'patio:request',id,command,args},location.origin);
  });
}

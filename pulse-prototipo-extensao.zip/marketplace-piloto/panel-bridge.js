// Runs in the extension's isolated world, only on the local Pátio panel.
(() => {
  if(location.origin!=='http://127.0.0.1:4178'||!['/','/panel.html'].includes(location.pathname))return;
  const commands=new Set(['PING','PREPARE','STATUS','FOCUS']);
  window.addEventListener('message',async event=>{
    const m=event.data;
    if(event.source!==window||event.origin!==location.origin||m?.channel!=='patio:request'||typeof m.id!=='string'||!commands.has(m.command))return;
    let reply;
    try { reply=await chrome.runtime.sendMessage({type:'LOCAL_'+m.command,args:m.args}); }
    catch { reply={ok:false,error:'A extensão foi atualizada. Recarregue esta página para reconectar.'}; }
    window.postMessage({channel:'patio:reply',id:m.id,...reply},location.origin);
  });
})();
